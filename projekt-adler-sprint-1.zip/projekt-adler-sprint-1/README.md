# Projekt ADLER

KI-gestütztes Funktraining für U-Bahn, Straßenbahn, Bus und Verkehrsmeister.

## Sprint 1
- klickbare Startoberfläche
- Rollenwahl
- Szenarioauswahl
- Schwierigkeitsgrad
- Push-to-Talk-Platzhalter
- FastAPI-Backend mit Health-Endpoint

## Frontend testen
`frontend/index.html` öffnen.

## Backend starten
```bash
cd backend
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Danach `http://localhost:8000/health` öffnen.
