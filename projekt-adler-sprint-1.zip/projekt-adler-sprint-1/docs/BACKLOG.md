# Backlog

## Muss
- [x] Projektstruktur
- [x] Startoberfläche
- [x] Rollenwahl
- [x] Szenarioauswahl
- [x] Push-to-Talk-Oberfläche
- [ ] Voice-KI
- [ ] Gesprächsprotokoll
- [ ] Abschlussbewertung
- [ ] Dienstanweisungsprüfung
