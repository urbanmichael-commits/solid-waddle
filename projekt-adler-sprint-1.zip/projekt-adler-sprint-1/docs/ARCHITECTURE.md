# Architektur

Projekt ADLER besteht aus Browser-Frontend, Backend-API, Voice-KI, Szenario-Engine und Bewertungsmodul.

## Sprint 1
- Repository-Struktur
- klickbare Trainingsoberfläche
- Rollen- und Szenarioauswahl
- Push-to-Talk-Platzhalter
- Backend-Health-Endpoint

## Sprint 2
- echte Voice-Verbindung
- Leitstellenrolle Adler
- Szenario „Bewusstlose Person“
- Gesprächsprotokoll
